namespace PerfumeCatalog.Domain.Entities;

public enum PerfumeGender
{
    Unspecified = 0,
    Male,
    Female,
    Unisex
}

public class Perfume
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Brand { get; set; } = "";
    public double SizeMl { get; set; }
    public decimal Price { get; set; }
    public PerfumeGender Gender { get; set; }
    public string? Notes { get; set; }
}