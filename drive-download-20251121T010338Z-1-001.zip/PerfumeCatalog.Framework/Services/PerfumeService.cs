using Microsoft.EntityFrameworkCore;
using PerfumeCatalog.Domain.Entities;
using PerfumeCatalog.Framework.Persistence;

namespace PerfumeCatalog.Framework.Services;

public class PerfumeService : IPerfumeService
{
    private readonly PerfumeCatalogDbContext _db;

    public PerfumeService(PerfumeCatalogDbContext db) => _db = db;

    public Task<List<Perfume>> GetAllAsync() =>
        _db.Perfumes.OrderBy(p => p.Brand).ThenBy(p => p.Name).ToListAsync();

    public Task<Perfume?> GetByIdAsync(int id) =>
        _db.Perfumes.FirstOrDefaultAsync(p => p.Id == id);

    public async Task<Perfume> AddAsync(Perfume perfume)
    {
        _db.Perfumes.Add(perfume);
        await _db.SaveChangesAsync();
        return perfume;
    }

    public async Task<Perfume> UpdateAsync(Perfume perfume)
    {
        _db.Perfumes.Update(perfume);
        await _db.SaveChangesAsync();
        return perfume;
    }

    public async Task DeleteAsync(int id)
    {
        var entity = await _db.Perfumes.FindAsync(id);
        if (entity is null) return;
        _db.Perfumes.Remove(entity);
        await _db.SaveChangesAsync();
    }
}