using PerfumeCatalog.Domain.Entities;

namespace PerfumeCatalog.Framework.Services;

public interface IPerfumeService
{
    Task<List<Perfume>> GetAllAsync();
    Task<Perfume?> GetByIdAsync(int id);
    Task<Perfume> AddAsync(Perfume perfume);
    Task<Perfume> UpdateAsync(Perfume perfume);
    Task DeleteAsync(int id);
}