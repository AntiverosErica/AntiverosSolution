using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json; // <-- Add this using directive
using System.IO;

namespace PerfumeCatalog.Framework.Persistence;

public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<PerfumeCatalogDbContext>
{
    public PerfumeCatalogDbContext CreateDbContext(string[] args)
    {
        // Look for appsettings.json in WPF project during design-time migrations
        var basePath = Directory.GetCurrentDirectory();
        var configuration = new ConfigurationBuilder()
            .SetBasePath(basePath)
            .AddJsonFile("appsettings.json", optional: true)
            .Build();

        var conn = configuration.GetConnectionString("PerfumeCatalog")
                   ?? "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PerfumeCAT;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

        var optionsBuilder = new DbContextOptionsBuilder<PerfumeCatalogDbContext>()
            .UseSqlServer(conn);

        return new PerfumeCatalogDbContext(optionsBuilder.Options);
    }
}