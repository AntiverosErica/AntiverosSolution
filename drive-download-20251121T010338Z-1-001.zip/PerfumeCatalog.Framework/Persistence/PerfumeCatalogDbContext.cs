using Microsoft.EntityFrameworkCore;
using PerfumeCatalog.Domain.Entities;

namespace PerfumeCatalog.Framework.Persistence;

public class PerfumeCatalogDbContext : DbContext
{
    public PerfumeCatalogDbContext(DbContextOptions<PerfumeCatalogDbContext> options) : base(options) { }

    public DbSet<Perfume> Perfumes => Set<Perfume>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Perfume>(e =>
        {
            e.Property(p => p.Name).HasMaxLength(200).IsRequired();
            e.Property(p => p.Brand).HasMaxLength(150).IsRequired();
            e.Property(p => p.Price).HasColumnType("decimal(10,2)");
        });
    }
}