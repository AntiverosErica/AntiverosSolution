﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.IO;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using PerfumeCatalog.Framework.Persistence;
using PerfumeCatalog.Framework.Services;
using PerfumeCatalog.WPF.ViewModels;

namespace PerfumeCatalog.WPF;

public partial class App : Application
{
    private IHost? _host;

    protected override void OnStartup(StartupEventArgs e)
    {
        _host = Host.CreateDefaultBuilder()
            .ConfigureAppConfiguration(cfg =>
            {
                cfg.SetBasePath(AppContext.BaseDirectory) // use base directory where files are copied
                   .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            })
            .ConfigureServices((ctx, services) =>
            {
                var conn = ctx.Configuration.GetConnectionString("PerfumeCatalog")
                          ?? "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PerfumeCAT;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
                services.AddDbContext<PerfumeCatalogDbContext>(opt => opt.UseSqlServer(conn));
                services.AddScoped<IPerfumeService, PerfumeService>();
                services.AddSingleton<MainWindowViewModel>();
                services.AddTransient<MainWindow>(sp =>
                {
                    var w = new MainWindow { DataContext = sp.GetRequiredService<MainWindowViewModel>() };
                    return w;
                });
            })
            .Build();

        _host.Start();
        var mainWindow = _host.Services.GetRequiredService<MainWindow>();
        mainWindow.Show();
        base.OnStartup(e);
    }

    protected override async void OnExit(ExitEventArgs e)
    {
        if (_host is not null)
            await _host.StopAsync(TimeSpan.FromSeconds(2));
        base.OnExit(e);
    }
}
