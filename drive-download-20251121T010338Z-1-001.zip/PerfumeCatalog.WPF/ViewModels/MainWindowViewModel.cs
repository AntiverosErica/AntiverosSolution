using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using PerfumeCatalog.Framework.Services;
using PerfumeCatalog.Domain.Entities;
using PerfumeCatalog.WPF.Commands;

namespace PerfumeCatalog.WPF.ViewModels;

public class MainWindowViewModel : BaseViewModel
{
    private readonly IPerfumeService _service;

    public ObservableCollection<PerfumeItemViewModel> Perfumes { get; } = new();
    public IReadOnlyList<PerfumeGender> PerfumeGenders { get; } = Enum.GetValues<PerfumeGender>(); // added

    private PerfumeItemViewModel? _selected;
    public PerfumeItemViewModel? Selected
    {
        get => _selected;
        set
        {
            Set(ref _selected, value);
            DeleteCommand.RaiseCanExecuteChanged(); // ensure button enabled/disabled when selection changes
        }
    }

    public PerfumeItemViewModel Editor { get; private set; } = new();

    public RelayCommand RefreshCommand { get; }
    public RelayCommand NewCommand { get; }
    public RelayCommand SaveCommand { get; }
    public RelayCommand DeleteCommand { get; }

    public MainWindowViewModel(IPerfumeService service)
    {
        _service = service;

        RefreshCommand = new RelayCommand(async _ => await LoadAsync());
        SaveCommand = new RelayCommand(async _ => await SaveAsync(),
            _ => !string.IsNullOrWhiteSpace(Editor.Name) && !string.IsNullOrWhiteSpace(Editor.Brand));
        NewCommand = new RelayCommand(_ => AttachEditor(new PerfumeItemViewModel()));
        DeleteCommand = new RelayCommand(async _ => await DeleteAsync(), _ => Selected is not null);

        AttachEditor(Editor);
        _ = LoadAsync();
    }

    private void AttachEditor(PerfumeItemViewModel newEditor)
    {
        if (Editor is not null)
            Editor.PropertyChanged -= Editor_PropertyChanged;
        Editor = newEditor;
        Editor.PropertyChanged += Editor_PropertyChanged;
        RaisePropertyChanged(nameof(Editor));
        SaveCommand.RaiseCanExecuteChanged();
    }

    private void Editor_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(PerfumeItemViewModel.Name) or nameof(PerfumeItemViewModel.Brand))
            SaveCommand.RaiseCanExecuteChanged();
    }

    private async Task LoadAsync()
    {
        Perfumes.Clear();
        var all = await _service.GetAllAsync();
        foreach (var p in all.Select(PerfumeItemViewModel.FromEntity))
            Perfumes.Add(p);
    }

    public void BeginEditSelected()
    {
        if (Selected is null) return;
        AttachEditor(PerfumeItemViewModel.FromEntity(Selected.ToEntity()));
    }

    private async Task SaveAsync()
    {
        if (Editor.Id == 0)
        {
            var added = await _service.AddAsync(Editor.ToEntity());
            Perfumes.Add(PerfumeItemViewModel.FromEntity(added));
        }
        else
        {
            var updated = await _service.UpdateAsync(Editor.ToEntity());
            var existing = Perfumes.FirstOrDefault(p => p.Id == updated.Id);
            if (existing is not null)
            {
                existing.Name = updated.Name;
                existing.Brand = updated.Brand;
                existing.SizeMl = updated.SizeMl;
                existing.Price = updated.Price;
                existing.Gender = updated.Gender;
                existing.Notes = updated.Notes;
            }
        }
        AttachEditor(new PerfumeItemViewModel());
    }

    private async Task DeleteAsync()
    {
        if (Selected is null) return;
        await _service.DeleteAsync(Selected.Id);
        Perfumes.Remove(Selected);
        Selected = null; // will trigger CanExecute reevaluation
    }
}