using PerfumeCatalog.Domain.Entities;

namespace PerfumeCatalog.WPF.ViewModels;

public class PerfumeItemViewModel : BaseViewModel
{
    private int _id;
    private string _name = "";
    private string _brand = "";
    private double _sizeMl;
    private decimal _price;
    private PerfumeGender _gender;
    private string? _notes;

    public int Id { get => _id; set => Set(ref _id, value); }
    public string Name { get => _name; set => Set(ref _name, value); }
    public string Brand { get => _brand; set => Set(ref _brand, value); }
    public double SizeMl { get => _sizeMl; set => Set(ref _sizeMl, value); }
    public decimal Price { get => _price; set => Set(ref _price, value); }
    public PerfumeGender Gender { get => _gender; set => Set(ref _gender, value); }
    public string? Notes { get => _notes; set => Set(ref _notes, value); }

    public Perfume ToEntity() => new()
    {
        Id = Id,
        Name = Name,
        Brand = Brand,
        SizeMl = SizeMl,
        Price = Price,
        Gender = Gender,
        Notes = Notes
    };

    public static PerfumeItemViewModel FromEntity(Perfume p) => new()
    {
        Id = p.Id,
        Name = p.Name,
        Brand = p.Brand,
        SizeMl = p.SizeMl,
        Price = p.Price,
        Gender = p.Gender,
        Notes = p.Notes
    };
}